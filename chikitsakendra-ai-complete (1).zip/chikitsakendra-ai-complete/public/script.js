/* ==========================================
   CHIKITSAKENDRA AI
   FRONTEND DEMONSTRATION
========================================== */


/* ================= START ASSESSMENT ================= */

function startAssessment() {

    document.getElementById("history").scrollIntoView({
        behavior: "smooth"
    });

    setTimeout(() => {

        document.getElementById("symptoms").focus();

    }, 700);
}



/* ================= OPEN REPORTS ================= */

function openReports() {

    document.getElementById("reports").scrollIntoView({
        behavior: "smooth"
    });

}



/* ================= QUICK AI OPTIONS ================= */

function quickQuestion(type) {

    const status = document.getElementById("voiceStatus");

    if (type === "Symptoms") {

        document.getElementById("symptoms").focus();

        status.innerText =
            "AI Assistant: Please describe your main symptoms.";

    }

    if (type === "Medicines") {

        status.innerText =
            "AI Assistant: Medication details can be added for doctor verification.";

    }

    if (type === "Reports") {

        openReports();

    }

}



/* ================= VOICE INPUT ================= */

function startVoice() {

    const voiceStatus =
        document.getElementById("voiceStatus");

    const button =
        document.getElementById("voiceButton");


    if (!("webkitSpeechRecognition" in window) &&
        !("SpeechRecognition" in window)) {

        voiceStatus.innerText =
            "Voice input is not supported in this browser.";

        return;

    }


    const SpeechRecognition =
        window.SpeechRecognition ||
        window.webkitSpeechRecognition;


    const recognition =
        new SpeechRecognition();


    recognition.lang = "en-IN";

    recognition.continuous = false;

    recognition.interimResults = false;


    voiceStatus.innerText =
        "🎙️ Listening... Please speak clearly.";


    if (button) {

        button.style.transform =
            "scale(1.03)";

    }


    recognition.start();


    recognition.onresult = function(event) {

        const transcript =
            event.results[0][0].transcript;


        document.getElementById("symptoms").value =
            transcript;


        voiceStatus.innerText =
            "✓ Voice input captured successfully.";

    };


    recognition.onerror = function() {

        voiceStatus.innerText =
            "Unable to capture voice. Please try again.";

    };


    recognition.onend = function() {

        if (button) {

            button.style.transform =
                "scale(1)";

        }

    };

}



/* ================= CONTINUE HISTORY ================= */

function continueHistory() {

    const symptoms =
        document.getElementById("symptoms").value.trim();

    const duration =
        document.getElementById("duration").value;


    if (symptoms === "") {

        alert(
            "Please describe your main health concern first."
        );

        return;

    }


    document.getElementById("summaryComplaint")
        .innerText = symptoms;


    document.getElementById("summaryDuration")
        .innerText = duration;


    /* Update progress */

    document.getElementById("progressFill").style.width =
        "45%";


    document.getElementById("confidenceFill").style.width =
        "55%";


    document.getElementById("confidenceValue")
        .innerText = "55%";


    document.getElementById("summary")
        .scrollIntoView({
            behavior: "smooth"
        });

}



/* ================= FILE UPLOAD ================= */

function displayFiles() {

    const input =
        document.getElementById("fileInput");

    const fileList =
        document.getElementById("fileList");


    fileList.innerHTML = "";


    if (input.files.length === 0) {

        return;

    }


    for (let i = 0; i < input.files.length; i++) {

        const file =
            input.files[i];


        const item =
            document.createElement("div");


        item.className =
            "file-item";


        item.innerHTML =
            "📄 <strong>" +
            file.name +
            "</strong> — " +
            formatFileSize(file.size);


        fileList.appendChild(item);

    }


    document.getElementById("progressFill")
        .style.width = "65%";

}



/* ================= FILE SIZE ================= */

function formatFileSize(bytes) {

    if (bytes < 1024) {

        return bytes + " B";

    }

    if (bytes < 1024 * 1024) {

        return (bytes / 1024).toFixed(1) + " KB";

    }

    return (
        bytes /
        (1024 * 1024)
    ).toFixed(1) + " MB";

}



/* ================= DOWNLOAD SUMMARY ================= */

function downloadSummary() {

    const complaint =
        document.getElementById("summaryComplaint")
        .innerText;

    const duration =
        document.getElementById("summaryDuration")
        .innerText;


    const content = `
CHIKITSAKENDRA AI
Digital Patient Intake Summary
--------------------------------

Chief Complaint:
${complaint}

Duration:
${duration}

Previous Medical History:
To be verified by healthcare professional.

Medications / Allergies:
To be verified by healthcare professional.

--------------------------------
AI-assisted information.
Professional verification required.
`;


    const blob =
        new Blob(
            [content],
            { type: "text/plain" }
        );


    const url =
        URL.createObjectURL(blob);


    const link =
        document.createElement("a");


    link.href = url;

    link.download =
        "ChikitsaKendra_Patient_Summary.txt";


    link.click();


    URL.revokeObjectURL(url);

}



/* ================= DOCTOR REVIEW ================= */

function sendDoctorReview() {

    const consent =
        document.getElementById("consent");


    if (!consent.checked) {

        alert(
            "Please provide consent before sending information for this demonstration."
        );

        return;

    }


    document.getElementById("progressFill")
        .style.width = "100%";


    alert(
        "✓ Patient summary prepared for doctor review.\n\nThis is a frontend demonstration."
    );

}



/* ================= EMERGENCY UI ================= */

function showEmergency() {

    document
        .getElementById("emergencyBox")
        .classList.remove("hidden");

}


function closeEmergency() {

    document
        .getElementById("emergencyBox")
        .classList.add("hidden");

}



/* ================= LANGUAGE ================= */

document
    .getElementById("language")
    .addEventListener("change", function () {

        const selected =
            this.value;


        if (selected === "हिन्दी") {

            alert(
                "हिन्दी भाषा विकल्प चुना गया।"
            );

        }

        if (selected === "বাংলা") {

            alert(
                "বাংলা ভাষা বিকল্প নির্বাচিত হয়েছে।"
            );

        }

    });



/* ================= DRAG & DROP ================= */

const dropZone =
    document.querySelector(".drop-zone");


const fileInput =
    document.getElementById("fileInput");


dropZone.addEventListener(
    "dragover",
    function(event) {

        event.preventDefault();

        dropZone.style.background =
            "#f0faf8";

        dropZone.style.borderColor =
            "#087f73";

    }
);


dropZone.addEventListener(
    "dragleave",
    function() {

        dropZone.style.background =
            "";

        dropZone.style.borderColor =
            "";

    }
);


dropZone.addEventListener(
    "drop",
    function(event) {

        event.preventDefault();


        fileInput.files =
            event.dataTransfer.files;


        displayFiles();


        dropZone.style.background =
            "";

        dropZone.style.borderColor =
            "";

    }
);
