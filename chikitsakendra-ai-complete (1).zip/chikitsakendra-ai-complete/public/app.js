/* ChikitsaKendra AI - MySQL integration layer (with auth) */
(() => {
  const state = { patientId: null, patientCode: null, intakeId: null, consent: false, sessionToken: null };

  function getStaffToken() { return sessionStorage.getItem('chikitsaStaffToken'); }
  function setStaffToken(t) { t ? sessionStorage.setItem('chikitsaStaffToken', t) : sessionStorage.removeItem('chikitsaStaffToken'); }

  // `auth` = 'patient' (default, sends the patient session token) or 'staff' (sends the doctor/admin JWT) or 'none'.
  const api = async (url, options = {}) => {
    const { auth = 'patient', headers = {}, ...rest } = options;
    const finalHeaders = { ...headers };
    if (auth === 'patient' && state.sessionToken) finalHeaders.Authorization = `Bearer ${state.sessionToken}`;
    if (auth === 'staff') {
      const token = getStaffToken();
      if (token) finalHeaders.Authorization = `Bearer ${token}`;
    }
    const response = await fetch(url, { ...rest, headers: finalHeaders });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  };

  function toastMessage(message) {
    if (typeof toast === 'function') return toast(message);
    alert(message);
  }

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value || '—';
  }

  function applyPreferredLanguage(language) {
    const buttons = [...document.querySelectorAll('.lang-group button')];
    const supportedLanguages = buttons.map(button => button.textContent.trim());
    const selectedLanguage = supportedLanguages.includes(language) ? language : 'English';
    buttons.forEach(button => {
      button.classList.toggle('active', button.textContent.trim() === selectedLanguage);
    });
    if (typeof window.applyTranslations === 'function') window.applyTranslations(selectedLanguage);
    return selectedLanguage;
  }

  async function boot() {
    try {
      const saved = localStorage.getItem('chikitsaPatient');
      if (saved) Object.assign(state, JSON.parse(saved));
      let preferredLanguage = localStorage.getItem('chikitsaPreferredLanguage') ||
        document.querySelector('.lang-group .active')?.textContent?.trim() || 'English';
      preferredLanguage = applyPreferredLanguage(preferredLanguage);
      if (!state.patientId || !state.sessionToken) {
        const patient = await api('/api/patients/anonymous', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, auth: 'none',
          body: JSON.stringify({ preferredLanguage })
        });
        Object.assign(state, { patientId: patient.id, patientCode: patient.patientCode, sessionToken: patient.sessionToken });
        localStorage.setItem('chikitsaPatient', JSON.stringify(state));
      }
      const patient = await api(`/api/patients/${state.patientId}`);
      preferredLanguage = localStorage.getItem('chikitsaPreferredLanguage') || patient.preferred_language || preferredLanguage;
      preferredLanguage = applyPreferredLanguage(preferredLanguage);
      localStorage.setItem('chikitsaPreferredLanguage', preferredLanguage);
      state.consent = patient.consent_status === 'granted';
      localStorage.setItem('chikitsaPatient', JSON.stringify(state));
      const label = document.querySelector('.user-meta strong');
      if (label && state.patientCode) label.textContent = `Patient ${state.patientCode}`;
      await refreshStats();
    } catch (error) {
      console.error(error);
      // Session token was rejected (e.g. DB reset) — drop the stale local state so boot() can re-provision cleanly next load.
      if (String(error.message).includes('Invalid patient session')) {
        localStorage.removeItem('chikitsaPatient');
      }
    }
  }

  async function refreshStats() {
    try {
      const stats = await api('/api/dashboard/stats', { auth: 'none' });
      const values = document.querySelectorAll('.stat strong');
      if (values[0]) values[0].textContent = stats.patients;
      if (values[1]) values[1].textContent = stats.intakes;
      if (values[2]) values[2].textContent = stats.reports;
      if (values[4]) values[4].textContent = stats.pendingReviews;
    } catch (_) {}
  }

  window.saveSymptom = async function saveSymptomWithMySQL() {
    const input = document.getElementById('symptom');
    const value = input?.value?.trim();
    if (!value) return toastMessage('Please describe your main problem first.');
    if (!state.patientId) return toastMessage('Database session is not ready yet. Please try again.');
    try {
      const result = await api('/api/intakes', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chiefComplaint: value })
      });
      state.intakeId = result.id;
      localStorage.setItem('chikitsaPatient', JSON.stringify(state));
      setText('summaryComplaint', value);
      setText('fullComplaint', value);
      setText('historyComplaint', value);
      toastMessage('✓ Intake saved to MySQL.');
      if (typeof showPage === 'function') showPage('history');
      await refreshStats();
    } catch (error) {
      toastMessage(error.message);
    }
  };

  window.giveConsent = async function giveConsentWithMySQL() {
    if (!state.patientId) return toastMessage('Database session is not ready yet.');
    try {
      const result = await api(`/api/patients/${state.patientId}/consent`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ granted: true })
      });
      state.consent = result.consentStatus === 'granted';
      localStorage.setItem('chikitsaPatient', JSON.stringify(state));
      toastMessage('✓ Consent recorded securely in MySQL.');
    } catch (error) { toastMessage(error.message); }
  };

  window.fileSelected = async function uploadReportsWithMySQL(input) {
    if (!input?.files?.length) return;
    if (!state.patientId) return toastMessage('Database session is not ready yet.');
    const form = new FormData();
    [...input.files].forEach(file => form.append('reports', file));
    if (state.intakeId) form.append('intakeId', state.intakeId);
    try {
      const result = await api(`/api/patients/${state.patientId}/reports`, { method: 'POST', body: form });
      toastMessage(`✓ ${result.files.length} report(s) saved to MySQL.`);
      await refreshStats();
    } catch (error) { toastMessage(error.message); }
  };

  window.sendDoctorReview = async function sendDoctorReviewWithMySQL() {
    if (!state.intakeId) return toastMessage('Save the patient intake before sending it to doctor review.');
    if (!state.consent) return toastMessage('Please provide consent before sending information for review.');
    try {
      await api(`/api/intakes/${state.intakeId}/doctor-review`, { method: 'POST' });
      toastMessage('✓ Patient summary sent to the doctor review queue.');
      await refreshStats();
      if (typeof showPage === 'function') showPage('doctor');
    } catch (error) { toastMessage(error.message); }
  };

  window.changeLanguage = async function changeLanguageWithMySQL(_button, language) {
    const selectedLanguage = applyPreferredLanguage(language);
    localStorage.setItem('chikitsaPreferredLanguage', selectedLanguage);
    if (state.patientId) {
      try {
        await api(`/api/patients/${state.patientId}`, {
          method: 'PATCH', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ preferredLanguage: selectedLanguage })
        });
        toastMessage(`Language preference saved: ${selectedLanguage}`);
      } catch (error) { toastMessage(`Language changed for this session, but could not be saved: ${error.message}`); }
    } else toastMessage(`Language changed to ${selectedLanguage}`);
  };

  // ---- Doctor / staff auth + live queue ----

  window.staffLogin = async function staffLogin() {
    const username = document.getElementById('staffUsername')?.value?.trim();
    const password = document.getElementById('staffPassword')?.value;
    const errEl = document.getElementById('staffLoginError');
    if (errEl) errEl.textContent = '';
    if (!username || !password) { if (errEl) errEl.textContent = 'Enter a username and password.'; return; }
    try {
      const result = await api('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, auth: 'none',
        body: JSON.stringify({ username, password })
      });
      setStaffToken(result.token);
      sessionStorage.setItem('chikitsaStaffUsername', username);
      await window.onEnterDoctorPage();
    } catch (error) {
      if (errEl) errEl.textContent = error.message;
    }
  };

  window.staffLogout = function staffLogout() {
    setStaffToken(null);
    window.onEnterDoctorPage();
  };

  function renderQueue(reviews) {
    const body = document.getElementById('doctorLiveQueueBody');
    if (!body) return;
    if (!reviews.length) { body.innerHTML = '<p style="color:var(--muted);">No reviews in the queue.</p>'; return; }
    body.innerHTML = reviews.map(r => `
      <div style="padding:10px 0;border-bottom:1px solid var(--border);">
        <strong>${r.patient_code}</strong> — ${r.chief_complaint || ''} (${r.duration || 'n/a'})<br>
        <span class="tag">${r.status}</span>
        <div style="margin-top:6px;">
          <button data-review-id="${r.id}" data-status="in_review" class="reviewActionBtn">Start review</button>
          <button data-review-id="${r.id}" data-status="approved" class="reviewActionBtn">Approve</button>
          <button data-review-id="${r.id}" data-status="rejected" class="reviewActionBtn">Reject</button>
        </div>
      </div>`).join('');
    body.querySelectorAll('.reviewActionBtn').forEach(btn => {
      btn.addEventListener('click', () => updateReview(btn.dataset.reviewId, btn.dataset.status));
    });
  }

  async function updateReview(reviewId, status) {
    try {
      await api(`/api/doctor/reviews/${reviewId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, auth: 'staff',
        body: JSON.stringify({ status })
      });
      await window.onEnterDoctorPage();
      await refreshStats();
    } catch (error) { toastMessage(error.message); }
  }

  window.onEnterDoctorPage = async function onEnterDoctorPage() {
    const gate = document.getElementById('doctorAuthGate');
    const live = document.getElementById('doctorLiveQueue');
    if (!gate || !live) return;
    if (!getStaffToken()) {
      gate.style.display = 'flex';
      live.style.display = 'none';
      return;
    }
    try {
      const reviews = await api('/api/doctor/reviews', { auth: 'staff' });
      gate.style.display = 'none';
      live.style.display = 'block';
      // Update profile display from stored username
      const username = sessionStorage.getItem('chikitsaStaffUsername') || 'Doctor';
      const initials = username.slice(0, 2).toUpperCase();
      const nameEl = document.getElementById('docProfileName');
      const initEl = document.getElementById('docProfileInitials');
      if (nameEl) nameEl.textContent = username;
      if (initEl) initEl.textContent = initials;
      renderQueue(reviews);
    } catch (error) {
      // Token invalid/expired — fall back to the login gate.
      setStaffToken(null);
      gate.style.display = 'flex';
      live.style.display = 'none';
    }
  };

  document.addEventListener('DOMContentLoaded', boot);
})();
