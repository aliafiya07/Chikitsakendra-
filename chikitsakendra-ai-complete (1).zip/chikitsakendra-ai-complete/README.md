# ChikitsaKendra AI — MySQL Integrated Version

This is the original ChikitsaKendra AI frontend connected to a real MySQL persistence layer through a Node.js/Express API, now with authentication, encryption, and other engineering-side hardening applied (see "Security hardening added" below).

The original project was explicitly browser-only and did not persist data to a backend. This version adds the missing persistence layer while preserving the existing UI.

**Only `public/` is served by the app.** Pre-integration original UI files have been removed from this distribution so the tree contains only the running application, scripts, schema, and documentation.

## Architecture

```text
Patient/Doctor Browser
        |
        v
Existing ChikitsaKendra UI
        |
        v
Node.js + Express REST API
   |              |
   |              +--> Local report storage (/uploads)
   |
   v
MySQL 8.4
  ├── patients
  ├── intakes
  ├── vitals
  ├── reports
  ├── summaries
  ├── doctor_reviews
  └── audit_logs
```

## What was integrated

- Patient/session record creation in MySQL
- Patient language preference persistence
- Consent persistence and consent check before doctor review
- Symptom/intake persistence
- Report upload to server + report metadata in MySQL
- Doctor review queue persistence and status updates
- Audit log for important patient workflow events
- Dashboard counters from MySQL
- Database connection status in the existing dashboard
- Dockerized MySQL + Node/Express application
- SQL schema and seed files

## Security hardening added

- **Auth/RBAC**: doctor/admin accounts (bcrypt-hashed, `users` table) sign in via `POST /api/auth/login` and get a JWT; all `/api/doctor/*` routes require it. Patients get an opaque, per-session bearer token at creation; only its hash is stored, and it's required on every subsequent patient read/write, scoped to that patient only.
- **Encryption at rest**: `patients.full_name` and `patients.mobile` are AES-256-GCM encrypted before hitting MySQL, using a key from `ENCRYPTION_KEY`. This protects the DB/backups but is not end-to-end encryption — the app server itself can still decrypt (see Limitations below).
- **Input validation** on every write endpoint via `express-validator`.
- **Rate limiting**: general API limit plus a stricter limit on `/api/auth/login`, with account lockout after 5 failed attempts.
- **Security headers** via `helmet`; CORS restricted to an explicit origin allow-list (`CORS_ALLOWED_ORIGINS`) instead of `*`.
- **CSRF**: mitigated by architecture rather than a CSRF token — all state-changing requests require a bearer token in the `Authorization` header (never a cookie), which a third-party site cannot attach to a forged request.
- **Audit logging**: every audit row now records `actor_type`/`actor_id` (who did it) and `ip_address`, not just what happened.
- **Retention scaffolding**: a `retention_policy` table plus `scripts/retention-cleanup.js` to delete old reports/audit rows — **not run automatically**; schedule it yourself (cron/Docker sidecar) once you've set real retention periods for your jurisdiction.

The frontend already contained symptom entry, report upload, consent and doctor-review screens; those actions were previously demo-only/browser-side.

## Fastest setup — Docker

Requirements: Docker Desktop.

1. Copy `.env.example` to `.env` and fill in real secrets (see "Generating secrets" below) — `docker-compose.yml` loads this file into the `app` container.
2. Start everything:

```bash
docker compose up --build
```

3. Create your first doctor/admin account (run once, from your host, with the same `.env` loaded — or `docker compose exec app node scripts/create-user.js ...`):

```bash
docker compose exec app node scripts/create-user.js drpriya "a-strong-password-here" doctor "Dr. Priya Sharma"
```

Optional — load encrypted demo patients, intakes, and doctor-review rows:

```bash
docker compose exec app node scripts/seed-demo-data.js
```

Then open:

```text
http://localhost:3000
```

Patients can use the app immediately (no login needed). To reach the doctor queue, open the "Doctor" tab and sign in with the account you just created.

### Documentation (for submission / viva)

| File | Contents |
|------|----------|
| `docs/PROJECT_REPORT.md` | Full project report (abstract → conclusion) |
| `docs/PPT_OUTLINE.md` | 12–15 slide presentation outline |
| `docs/VIVA_QA.md` | Oral exam Q&A sheet |

The first MySQL startup automatically executes:

- `database/schema.sql`
- `database/seed.sql`

To stop:

```bash
docker compose down
```

To remove the database volume as well:

```bash
docker compose down -v
```

## Manual setup

1. Install Node.js 22+ and MySQL 8+.
2. Create the database by running `database/schema.sql`.
3. Copy `.env.example` to `.env`, set your MySQL credentials, and generate the secrets below.
4. Install dependencies:

```bash
npm install
```

5. Create a doctor/admin account:

```bash
node scripts/create-user.js drpriya "a-strong-password-here" doctor "Dr. Priya Sharma"
```

6. Start the API/UI:

```bash
npm start
```

7. Open `http://localhost:3000`. The server refuses to start if `JWT_SECRET` or `ENCRYPTION_KEY` are still set to their placeholder values.

### Generating secrets

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"       # JWT_SECRET
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"    # ENCRYPTION_KEY
```

Put the output in `.env` as `JWT_SECRET=` and `ENCRYPTION_KEY=` respectively. Generate a fresh pair per environment (dev/staging/prod) — never reuse or commit these. **If `ENCRYPTION_KEY` is ever lost, every already-encrypted `full_name`/`mobile` value becomes permanently unreadable** — back it up somewhere separate from the database itself (e.g. a secrets manager), not in the repo.

## API

Auth: `Bearer <token>` in the `Authorization` header. Two kinds of token — a patient session token (returned by `POST /api/patients/anonymous`, scoped to that one patient) and a staff JWT (returned by `POST /api/auth/login`, role `doctor` or `admin`).

| Endpoint | Auth |
|---|---|
| `GET /api/health` | none |
| `GET /api/dashboard/stats` | none (aggregate counts only, no PII) |
| `POST /api/auth/login` | none (rate-limited, lockout after 5 fails) |
| `GET /api/auth/me` | staff |
| `POST /api/patients/anonymous` | none — issues the patient's session token |
| `GET /api/patients/:patientId` | patient (own record only) |
| `PATCH /api/patients/:patientId` | patient (own record only) |
| `POST /api/patients/:patientId/consent` | patient (own record only) |
| `POST /api/intakes` | patient |
| `POST /api/intakes/:intakeId/vitals` | patient (via intake ownership) |
| `POST /api/patients/:patientId/reports` | patient (own record only) |
| `GET /api/patients/:patientId/records` | patient (own record only) |
| `POST /api/intakes/:intakeId/doctor-review` | patient (via intake ownership) |
| `GET /api/doctor/reviews` | staff (`doctor` or `admin`) |
| `PATCH /api/doctor/reviews/:reviewId` | staff (`doctor` or `admin`) |

## Database

`database/schema.sql` creates the relational model and indexes. Foreign keys connect patients → intakes → vitals/summaries/reviews, while reports and audit logs are linked to the patient/intake lifecycle. `users` holds staff accounts (bcrypt hashes only). `retention_policy` configures `scripts/retention-cleanup.js`.

## Important: this is still not a production medical system

This pass hardened everything on the engineering side that doesn't require an outside account or a compliance process: auth/RBAC, encrypted PII at rest, input validation, rate limiting, security headers, CORS, actor-tagged audit logging, and retention scaffolding. That is real, working hardening — not a demo.

What's still missing, and *why it can't be code-generated*:

| Gap | What it actually needs |
|---|---|
| Multilingual ASR/TTS | A speech vendor account (Google/Azure/AWS Speech, etc.) and API keys you provide |
| OCR on uploaded reports | An OCR vendor/library choice + credentials |
| Dynamic SOCRATES questioning, Ayush/Dashavidha Pariksha question trees | Clinical content authored by someone with medical domain expertise — this is content design, not engineering |
| LLM/clinical-engine integration | An LLM API key + a defined clinical-safety review of its outputs before they reach a doctor or patient |
| Streaming/WebSocket audio | Depends on the ASR/TTS vendor chosen above |
| Secure object storage (vs. local `/uploads`) | A cloud storage account (S3/GCS/Azure Blob) and its own IAM setup |
| Regulatory/security review | A real audit and legal sign-off for your jurisdiction (e.g. India's DPDP Act, or HIPAA if this ever touches US patients) — not something any code change can satisfy |
| Backups, monitoring, on-call | Your hosting/infra decisions once you know where this deploys |

Treat everything in this repo as a hardened prototype, not a cleared-for-patients product, until those items are addressed by the people/processes they actually require.
