// scripts/migrate-audio.js
const pool = require('../db');

async function migrate() {
    try {
        // Create audio_recordings table
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS audio_recordings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                patient_id INT NOT NULL,
                session_id VARCHAR(255) NOT NULL,
                filename VARCHAR(255) NOT NULL,
                storage_url TEXT NOT NULL,
                duration_seconds INT DEFAULT 0,
                size_bytes INT NOT NULL,
                format VARCHAR(20) NOT NULL,
                status ENUM('recording', 'processing', 'completed', 'failed') DEFAULT 'recording',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
                INDEX idx_patient_session (patient_id, session_id)
            )
        `);

        // Add storage_url to reports table if not exists
        try {
            await pool.execute(`
                ALTER TABLE reports ADD COLUMN storage_url TEXT AFTER storage_path
            `);
        } catch (e) {
            console.log('Column storage_url already exists');
        }

        try {
            await pool.execute(`
                ALTER TABLE reports MODIFY storage_path VARCHAR(500) NULL
            `);
        } catch (e) {
            console.log('Could not modify storage_path');
        }

        console.log('✅ Migration completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    }
}

migrate();